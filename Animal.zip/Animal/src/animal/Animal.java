/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package animal;

/**
 *
 * @author sstan
 */
public class Animal {
// Implement class inheritance
    
    public int age;
    public String gender; 
    
    public void isMammal() {
        System.out.println("This is a public method: isMammal()");
    } // end of isMammal()
    
    public void mate() {
      System.out.println("This is a public method: mate()");  
    } // end of mate()
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { 
        // create an Animal object called myAnimal
        Animal myAnimal = new Animal();
        myAnimal.isMammal();
        myAnimal.mate();
        
        // a Fish object called myFish
        Fish myFish = new Fish(); 
                
        // a Zebra object called myZebra. 
        Zebra myZebra = new Zebra(); 
        myZebra.run(); 
        
    }
    
}
